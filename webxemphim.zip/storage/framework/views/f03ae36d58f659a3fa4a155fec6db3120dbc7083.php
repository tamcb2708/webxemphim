<!-- //banner-bottom -->
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v5.0&appId=2474475439538110&autoLogAppEvents=1"></script>
<div class="general_social_icons">
	<nav class="social">
		<ul>
			<li class="w3_facebook"><div data-layout="box_count" data-href="http://minhtalent.dx.am/index.php" data-size="large"><a target="_blank" title="Share MinMovies đến với bạn bè trên Facebook!" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>">Facebook<i class="fab fa-facebook-f"></i></a></div></li>
		</ul>
  </nav>
</div>
<?php /**PATH C:\xampp\htdocs\webxemphim2\resources\views/user/user_layout/social.blade.php ENDPATH**/ ?>