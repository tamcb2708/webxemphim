<!-- footer -->
<div class="footer">
    <div class="container">
        <div class="w3ls_footer_grid">
            <div class="col-md-6 w3ls_footer_grid_left">
                <div class="w3ls_footer_grid_left1">
                    <h2>liên hệ với chúng tôi</h2>
                    <div class="w3ls_footer_grid_left1_pos">
                        <form action="" method="post">
                            <input type="email" name="email" placeholder="Email..." required="">
                            <input type="submit" name="sendmail" value="Gửi">
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6 w3ls_footer_grid_right">
            <a href="<?php echo e(route('user.index')); ?>"><h2>Min<span>Movies</span></h2></a>
            </div>
            <div class="clearfix"> </div>
        </div>
        <div class="clearfix"> </div>
    </div>
    <div class="container text-center text-light" style="color: #FFF;">
        <p>&copy; 2019 Min Movies. All rights reserved</p>
    </div>
</div>
<!-- //footer -->
<?php /**PATH C:\xampp\htdocs\webxemphim\resources\views/user/user_layout/footer.blade.php ENDPATH**/ ?>