<footer class="sticky-footer bg-white">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright &copy; MinMovies 2020</span>
      </div>
    </div>
  </footer>
<?php /**PATH E:\laragon\www\webxemphim\resources\views/admin/admin_layout/footer.blade.php ENDPATH**/ ?>