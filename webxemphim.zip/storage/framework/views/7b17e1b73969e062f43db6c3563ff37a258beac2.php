<!-- header -->
<div class="header">
    <div class="container">
        <div class="row">
            <div class="col-md-4 text-center">
                <div class="w3layouts_logo">
                    <a href="<?php echo e(route('user.index')); ?>">
                        <h1>Min<span>Movies</span></h1>
                    </a>
                </div>
            </div>
            <div class="col-md-4 text-center">
                <div class="w3_search">
                    <form action="<?php echo e(route('user.search')); ?>" method="post" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="search" placeholder="Tìm kiếm" maxlength="50" required=""
                            oninvalid="this.setCustomValidity('Có phải bạn có quên mất gì đó?')"
                            oninput="this.setCustomValidity('')" onkeyup="showHint(this.value)">
                        <input type="submit" value="Tìm">
                        <div class="text-center">
                            <ul class="nav pull-center" style="position: relative">
                                <li class="dropdown"><a href="#" id="hoverHint" data-toggle="dropdown">
                                    <b class="caret"></b>
                                </a>
                                    <ul class="dropdown-menu pull-center">
                                        <li class="loggedin text-center text-black">
                                            <a href="#" id="txtHint" class="text-black"></a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4 text-center">
                <?php if(session('username_minmovies')): ?>
                <div>
                    <ul class="nav pull-right">
                        <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <h4><img src="public/user//images/hi.gif" style="padding-right: 10px;">Chào
                                    <?php echo e(Auth::user()->name); ?>

                                </h4> <b class="caret"></b>
                            </a>
                            <ul class="dropdown-menu pull-center">
                                <li class="loggedin"><a href="<?php echo e(route('user.getCabinet')); ?>"><i class="fad fa-film-alt"
                                            style="margin-right:14px; --fa-primary-color: black; --fa-secondary-color: dodgerblue; --fa-secondary-opacity: 1.0;"></i>Tủ
                                        phim</a>
                                </li>
                                <li class="loggedin"><a href="<?php echo e(route('user.boughtMovie')); ?>"><i
                                            class="fad fa-shopping-basket"
                                            style="margin-right:12px; --fa-primary-color: peru; --fa-secondary-color: black; --fa-secondary-opacity: 1.0;"></i>Phim
                                        đã mua</a>
                                </li>
                                <li class="loggedin"><a href="<?php echo e(route('user.getWallet')); ?>"><i class="fad fa-wallet"
                                            style="margin-right:15px; --fa-primary-color: gold; --fa-secondary-color: black; --fa-secondary-opacity: 1.0;"></i>Ví</a>
                                </li>
                                <li class="loggedin"><a href="<?php echo e(route('user.getProfile')); ?>"><i
                                            class="fad fa-user-edit"
                                            style="margin-right:10px; --fa-primary-color: limegreen; --fa-secondary-color: black; --fa-secondary-opacity: 1.0;"></i>Hồ
                                        sơ</a></li>
                                <li class="loggedin"><a href="<?php echo e(route('user.historyPayment')); ?>"><i
                                            class="fad fa-history"
                                            style="margin-right:14px; --fa-primary-color: deeppink; --fa-secondary-color: black; --fa-secondary-opacity: 1.0;"></i>Lịch
                                        sử giao dịch</a></li>
                                <li class="divider"></li>
                                <li class="loggedin"><a href="<?php echo e(route('user.logout')); ?>"><i class="fad fa-sign-out-alt"
                                            style="margin-right:14px; --fa-primary-color: crimson; --fa-secondary-color: black; --fa-secondary-opacity: 1.0;"></i>Đăng
                                        xuất</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <?php else: ?>
                <div class="w3l_sign_in_register">
                    <ul>
                        <li><img src="public/user/images/hello.gif" style="padding-right: 10px; width: 50px;"><a
                                href="#" data-toggle="modal" data-target="#myModal">Đăng Nhập</a></li>
                    </ul>
                </div>
                <?php endif; ?>


            </div>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>
<!-- //header -->
<!-- bootstrap-pop-up -->
<div class="modal video-modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                Đăng Nhập & Đăng Ký
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
            </div>
            <section>
                <div class="modal-body">
                    <div class="w3_login_module">
                        <div class="module form-module">
                            <div class="toggle signupnow"><i class="fas fa-user-plus" style="font-size:19px"></i>
                                <div class="tooltip" style="margin-left:35px">Đăng ký ngay!</div>
                            </div>
                            <div class="form">
                                <h3>Đăng Nhập</h3>
                                <form action="<?php echo e(route('user.postlogin')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" name="username" placeholder="Tài khoản" maxlength="20"
                                        required="" oninvalid="this.setCustomValidity('Có phải bạn có quên mất gì đó?')"
                                        oninput="this.setCustomValidity('')">
                                    <input type="password" name="password" placeholder="Mật khẩu" maxlength="30"
                                        required="" oninvalid="this.setCustomValidity('Có phải bạn có quên mất gì đó?')"
                                        oninput="this.setCustomValidity('')">
                                    <input type="submit" value="Đăng nhập" name="login">
                                </form>
                            </div>
                            <div class="form">
                                <h3>Đăng Ký Tài Khoản</h3>
                                <form action="<?php echo e(route('user.signup')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" name="name" maxlength="30" placeholder="Họ và tên" required=""
                                        oninvalid="this.setCustomValidity('Có phải bạn có quên mất gì đó?')"
                                        oninput="this.setCustomValidity('')">
                                    <input type="text" name="username" maxlength="20" placeholder="Tài khoản"
                                        required="" oninvalid="this.setCustomValidity('Có phải bạn có quên mất gì đó?')"
                                        oninput="this.setCustomValidity('')">
                                    <input type="password" name="password" maxlength="30" placeholder="Mật khẩu"
                                        required="" oninvalid="this.setCustomValidity('Có phải bạn có quên mất gì đó?')"
                                        oninput="this.setCustomValidity('')">
                                    <input type="email" name="email" maxlength="50" placeholder="Email" required=""
                                        oninvalid="this.setCustomValidity('Có phải bạn có quên mất gì đó?')"
                                        oninput="this.setCustomValidity('')">
                                    <input type="submit" value="Đăng ký" name="signup">
                                </form>
                            </div>
                            <div><a class="cta btn-block" href="<?php echo e(route('user.getrecoverpassword')); ?>">Quên mật
                                    khẩu?</a></div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<script>
    $('.toggle').click(function(){
      // Switches the Icon
      $(this).children('i').toggleClass('fa-pencil');
      // Switches the forms
      $('.form').animate({
        height: "toggle",
        'padding-top': 'toggle',
        'padding-bottom': 'toggle',
        opacity: "toggle"
      }, "slow");
    });
</script>
<!-- //bootstrap-pop-up -->
<!-- nav -->
<div class="movies_nav">
    <div class="container">
        <nav class="navbar navbar-default">
            <div class="navbar-header navbar-left">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                    data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
                <nav>
                    <ul class="nav navbar-nav">
                        <li><a href="<?php echo e(route('user.index')); ?>">Trang chủ</a></li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">thể loại <b
                                    class="caret"></b></a>
                            <ul class="dropdown-menu multi-column columns-2">
                                <li>
                                    <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-4">
                                        <ul class="multi-column-dropdown">
                                            <li><a href="<?php echo e(route('user.cate',$item->id)); ?>"><?php echo e($item->cate_name); ?></a></li>
                                        </ul>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="clearfix"></div>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">quốc gia<b class="caret"></b></a>
                            <ul class="dropdown-menu multi-column columns-3">
                                <li>
                                    <?php $__currentLoopData = $nation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-4">
                                        <ul class="multi-column-dropdown">
                                            <li><a href="<?php echo e(route('user.nation',$item->id)); ?>"><?php echo e($item->nation_name); ?></a>
                                            </li>
                                        </ul>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="clearfix"></div>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">năm sản xuất<b
                                    class="caret"></b></a>
                            <ul class="dropdown-menu multi-column columns-3">
                                <li>
                                    <?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-4">
                                        <ul class="multi-column-dropdown">
                                            <li><a href="<?php echo e(route('user.year',$item->id)); ?>"><?php echo e($item->year); ?></a></li>
                                        </ul>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="clearfix"></div>
                                </li>
                            </ul>
                        </li>
                        <li><a href="<?php echo e(route('user.list')); ?>">danh sách phim</a></li>
                        <li><a href="<?php echo e(route('user.trailer')); ?>">trailers phim</a></li>
                        <li><a href="<?php echo e(route('user.about')); ?>">giới thiệu</a></li>
                    </ul>
                </nav>
            </div>
        </nav>
    </div>
</div>
<?php if(session('thongbao')): ?>
<div class="alert alert-<?php echo e(session('thongbao_level')); ?>" style="border-radius:0px;">
    <h4 class="text-center"><?php echo session('thongbao'); ?></h4>
</div>
<?php endif; ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h4 class="text-center"><?php echo $error; ?></h4>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<script>
    function showHint(str) {
        var xhttp;
        if (str.length == 0) {
        document.getElementById("txtHint").innerHTML = "";
        return;
        }
        xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
        if (xhttp.readyState == 4 && xhttp.status == 200) {
            var parts = xhttp.responseText.split('|');
            document.getElementById("txtHint").innerHTML = parts[0];
            document.getElementById("movie_id").innerHTML = parts[1];
        }
        };
        xhttp.open("GET", "getHint/"+str, true);
        xhttp.send();
        $("#hoverHint").mouseover();
    }
</script>
<!-- //nav -->
<?php /**PATH C:\xampp\htdocs\webxemphim2\resources\views/user/user_layout/header.blade.php ENDPATH**/ ?>