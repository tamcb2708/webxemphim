<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Nation;
use Faker\Generator as Faker;

$factory->define(Nation::class, function (Faker $faker) {
    return [
        //
    ];
});
