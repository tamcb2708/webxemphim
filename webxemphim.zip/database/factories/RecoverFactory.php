<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Recover;
use Faker\Generator as Faker;

$factory->define(Recover::class, function (Faker $faker) {
    return [
        //
    ];
});
