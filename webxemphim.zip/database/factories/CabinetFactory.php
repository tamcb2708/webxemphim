<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Cabinet;
use Faker\Generator as Faker;

$factory->define(Cabinet::class, function (Faker $faker) {
    return [
        //
    ];
});
