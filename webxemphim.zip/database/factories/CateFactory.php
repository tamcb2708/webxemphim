<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Cate;
use Faker\Generator as Faker;

$factory->define(Cate::class, function (Faker $faker) {
    return [
        //
    ];
});
